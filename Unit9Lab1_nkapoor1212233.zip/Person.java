 /**
 * This program models a Person as having Name fullname and Date birthDay.
 * It includes appropriate methods to make the Person class functional and easy to reuse.
 * @author Neil Kapoor
*/
 
 public class Person
{
// initialize data fields. 
 private Name fullName;
 private Date birthDay;
/**
 * @pre fullName variable is valid. 
 * @post returns String form. 
*/
 public String getFirstName()
 {
 return fullName.getFirstName();
 }
 /**
 * @pre fullName variable is valid. 
 * @post returns String form. 
*/
 public String getLastName()
 {
 return fullName.getLastName();
 }
 /**
 * @pre birthDay variable is valid. 
 * @post returns String form. 
*/
 public String getBirthDayString()
 {
 return birthDay.getDateString();
 }
 
 /**
 * @pre n, bd variable is valid. 
 * @post initialize fields. 
*/
 public Person( Name n, Date bd )
 {
fullName = n;
 birthDay = bd;
 }
 /**
 * @pre fullName, birthDay variable is valid. 
 * @post initialize fields. 
*/
 public Person() // Default constructor
 {
 fullName = new Name();

 birthDay = new Date( 99, 99, 9999 );
 }

} 