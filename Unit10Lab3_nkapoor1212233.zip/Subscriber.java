/**
 * This program models the subscriber receiving the notification. 
 * @author Neil Kapoor
*/

public class Subscriber
{
 public void update()
 {
 }
}